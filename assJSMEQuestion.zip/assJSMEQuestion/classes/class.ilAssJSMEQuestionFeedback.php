<?php

require_once 'Modules/TestQuestionPool/classes/feedback/class.ilAssSingleOptionQuestionFeedback.php';

/**
 * @author Fred Neumann <fred.neumann@ili.fau.de>
 * @author Jesus Copado <jesus.copado@ili.fau.de>
 * @version $Id$
 *
 */

class ilAssJSMEQuestionFeedback extends ilAssSingleOptionQuestionFeedback
{
    
}